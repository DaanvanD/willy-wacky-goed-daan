# Will's Wacky website - static version
## Personal website for fork testing

Fork, download and destroy